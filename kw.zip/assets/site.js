(function(){
  document.documentElement.classList.remove('no-js');
  // New page visits always start at the top (anchor links still jump to their section)
  // New page visits always start at the top (anchor links still jump to their section; Back keeps your place)
  try{
    var nav=performance.getEntriesByType('navigation')[0];
    if(!location.hash && (!nav || nav.type==='navigate')){
      var top=function(){ window.scrollTo({top:0,left:0,behavior:'instant'}); };
      top(); requestAnimationFrame(top);
      window.addEventListener('load', function(){ top(); setTimeout(top,60); }, {once:true});
      window.addEventListener('pageshow', function(e){ if(!e.persisted) top(); }, {once:true});
    }
  }catch(e){}
  var head=document.querySelector('.site-head');
  function onScroll(){ if(head) head.classList.toggle('scrolled', window.scrollY>30); }
  onScroll(); window.addEventListener('scroll', onScroll, {passive:true});

  var btn=document.querySelector('.menu-btn'), nav=document.getElementById('nav');
  if(btn&&nav){ btn.addEventListener('click',function(){
    var open=nav.classList.toggle('open'); btn.setAttribute('aria-expanded', open);
  });}

  var els=document.querySelectorAll('.reveal');
  if('IntersectionObserver' in window){
    var io=new IntersectionObserver(function(entries){
      entries.forEach(function(e){ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target);} });
    },{rootMargin:'0px 0px -8% 0px',threshold:.08});
    els.forEach(function(el,i){ el.style.transitionDelay=((el.dataset.d||0)*90)+'ms'; io.observe(el); });
  } else { els.forEach(function(el){el.classList.add('in');}); }

  // Contact: prefill topic from #hash, validate, then go to thank-you page
  var form=document.getElementById('enquiry');
  var LIVE=/(^|\.)kylewillmington\.com\.au$/.test(location.hostname);
  var tsEl=form&&form.querySelector('.cf-turnstile'), TS_READY=!!(tsEl&&!/TURNSTILE_SITE_KEY/.test(tsEl.getAttribute('data-sitekey')||''));
  if(tsEl&&!TS_READY) tsEl.remove();
  if(form&&LIVE&&TS_READY){ var ts=document.createElement('script'); ts.src='https://challenges.cloudflare.com/turnstile/v0/api.js'; ts.async=true; ts.defer=true; document.head.appendChild(ts); }
  if(form){
    var topic=form.querySelector('#topic'), h=(location.hash||'').slice(1);
    var map={brand:'Brand identity & digital footprint',shortstay:'Short-stay setup & consulting',systems:'Business systems & automation',partner:'Partnership, media or something else',launch:'A business idea',speaking:'Speaking at an event',parents:'A talk or session for parents'};
    if(map[h]&&topic) topic.value=map[h];
    form.addEventListener('submit',function(ev){
      ev.preventDefault();
      var ok=true;
      form.querySelectorAll('[required]').forEach(function(f){
        var e=document.getElementById(f.id+'-err');
        var bad=!f.value.trim()||(f.type==='email'&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.value));
        if(e) e.textContent=bad?(f.type==='email'?'Please enter a valid email address.':'Please fill this in.'):'';
        if(bad){ ok=false; f.setAttribute('aria-invalid','true'); } else f.removeAttribute('aria-invalid');
      });
      if(form.querySelector('.hp input').value) return;
      if(!ok){ var first=form.querySelector('[aria-invalid=true]'); if(first) first.focus(); return; }
      if(!LIVE){ location.href='thank-you.html'; return; }
      var btn=form.querySelector('button[type=submit]'); btn.disabled=true; btn.textContent='Sending…';
      var fd=new FormData(form), body={};
      fd.forEach(function(v,k){body[k]=v;}); body.optin=!!form.querySelector('#optin').checked;
      body.token=(form.querySelector('[name="cf-turnstile-response"]')||{}).value||'';
      fetch('/api/enquiry',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
        .then(function(r){return r.json();}).then(function(r){
          if(r.ok){ location.href='/thank-you'; return; }
          if(r.error==='not-configured'){ mailFallback(); return; }
          throw 0;
        }).catch(function(){
          btn.disabled=false; btn.textContent='Send message →';
          document.getElementById('form-status').textContent='Sorry, that didn’t send. Please try again, or email hi@kylewillmington.com.au.';
        });
    });
  }
  // Until the email service is switched on, hand the message to the visitor's email app, addressed to hi@
  function mailFallback(){
    var f=document.getElementById('enquiry'), g=function(n){var e=f.querySelector('[name="'+n+'"]');return e?e.value.trim():'';};
    var subj='Website enquiry: '+(g('topic')||'General'), bodyTxt=g('message')+'\n\n'+g('name')+(g('business')?'\n'+g('business'):'')+'\n'+g('email');
    var href='mailto:hi@kylewillmington.com.au?subject='+encodeURIComponent(subj)+'&body='+encodeURIComponent(bodyTxt);
    var btn=f.querySelector('button[type=submit]'); btn.disabled=false; btn.textContent='Send message →';
    document.getElementById('form-status').innerHTML='Your email app is opening with your message ready to send. If it doesn’t open, email <a href="'+href+'">hi@kylewillmington.com.au</a>.';
    location.href=href;
  }
  document.querySelectorAll('[data-copy]').forEach(function(b){b.addEventListener('click',function(){
    var t=b.getAttribute('data-copy'),s=b.querySelector('span');
    try{navigator.clipboard.writeText(t).then(function(){s.textContent='Copied';setTimeout(function(){s.textContent='Copy';},1800);});}catch(e){}
  });});
  var y=document.querySelectorAll('[data-year]'); y.forEach(function(n){n.textContent=new Date().getFullYear();});
})();

// R34 tracker: draw squares from the saved amount, then refresh from the live total
(function(){
  var t=document.getElementById('r34-tracker'); if(!t) return;
  var goal=+t.dataset.goal||200000, grid=document.querySelector('.r34-grid');
  function money(n){ return '$'+Math.round(n).toLocaleString('en-AU'); }
  function draw(saved){
    saved=Math.max(0,Math.min(goal,+saved||0));
    var pct=saved/goal*100, p=pct<10?Math.round(pct*10)/10:Math.round(pct);
    t.querySelector('[data-r34=saved]').textContent=money(saved);
    t.querySelector('[data-r34=pct]').textContent=p+'%';
    t.querySelector('[data-r34=left]').textContent=money(goal-saved);
    var bar=t.querySelector('.r34-bar'); bar.setAttribute('aria-valuenow',Math.round(saved)); bar.querySelector('span').style.width=pct+'%';
    if(grid){ var full=Math.floor(saved/1000), rem=(saved%1000)/10, boxes=grid.children;
      for(var i=0;i<boxes.length;i++){ var b=boxes[i]; b.className=i<full?'on':(i===full&&rem>0?'part':''); b.style.setProperty('--p',i===full?rem+'%':'0%'); } }
  }
  draw(t.dataset.saved);
  if(/kylewillmington\.com\.au$|pages\.dev$/.test(location.hostname)){
    fetch('/api/r34',{cache:'no-store'}).then(function(r){return r.ok?r.json():null}).then(function(d){ if(d&&typeof d.saved==='number') draw(d.saved); }).catch(function(){});
  }
})();
