(function(){
  var total=document.getElementById('ra-total'), msg=document.getElementById('ra-msg'), code=document.getElementById('ra-code');
  function money(n){ return '$'+Math.round(n).toLocaleString('en-AU'); }
  function load(){ fetch('/api/r34',{cache:'no-store'}).then(function(r){return r.json()}).then(function(d){ total.textContent=money(d.saved); }).catch(function(){ total.textContent='unavailable'; }); }
  function add(amount){
    amount=Math.round(+amount); if(!amount){ msg.textContent='Enter an amount first.'; return; }
    if(!code.value){ msg.textContent='Enter your passcode first.'; code.focus(); return; }
    msg.textContent='Saving…';
    fetch('/api/r34',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({code:code.value,add:amount})})
      .then(function(r){ return r.json().then(function(d){ return {ok:r.ok,d:d}; }); })
      .then(function(x){
        if(x.ok){ total.textContent=money(x.d.saved); msg.textContent=(amount>0?'Added ':'Removed ')+money(Math.abs(amount))+'. The public page now shows '+money(x.d.saved)+'.'; }
        else msg.textContent={'bad-code':'That passcode isn’t right.','locked':'Too many wrong tries. Wait an hour and try again.','not-configured':'The update service isn’t switched on yet.'}[x.d.error]||'Something went wrong. Try again.';
      }).catch(function(){ msg.textContent='Couldn’t reach the server. Check your connection.'; });
  }
  document.querySelectorAll('[data-add]').forEach(function(b){ b.addEventListener('click',function(){ add(b.dataset.add); }); });
  document.getElementById('ra-custom').addEventListener('click',function(){ add(document.getElementById('ra-amt').value); });
  load();
})();
