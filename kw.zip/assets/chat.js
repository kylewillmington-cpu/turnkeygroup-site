// AI Kyle chat widget
(function () {
  var LIVE = /(^|\.)kylewillmington\.com\.au$/.test(location.hostname);
  var history = [], busy = false, sid;
  try { sid = sessionStorage.getItem('kw-sid'); } catch (e) {}
  if (!sid) { sid = Math.random().toString(36).slice(2) + Date.now().toString(36); try { sessionStorage.setItem('kw-sid', sid); } catch (e) {} }

  var root = document.createElement('div');
  root.className = 'kwchat';
  root.innerHTML =
    '<button class="kwc-launch" type="button" aria-label="Chat with AI Kyle" aria-expanded="false" aria-controls="kwc-panel"><span class="kwc-av" aria-hidden="true"></span><span class="kwc-launch-t">Ask AI Kyle</span></button>' +
    '<section class="kwc-panel" id="kwc-panel" role="dialog" aria-modal="false" aria-labelledby="kwc-title" hidden>' +
      '<header class="kwc-head"><span class="kwc-av lg" aria-hidden="true"></span><div><p id="kwc-title" class="kwc-title">AI Kyle</p><p class="kwc-sub">An AI version of Kyle. Replies instantly.</p></div>' +
      '<button class="kwc-close" type="button" aria-label="Close chat">×</button></header>' +
      '<div class="kwc-log" role="log" aria-live="polite"></div>' +
      '<div class="kwc-chips"></div>' +
      '<form class="kwc-form"><label for="kwc-in" class="sr-only">Message</label><textarea id="kwc-in" rows="1" maxlength="1200" placeholder="Ask me anything about my work…"></textarea><button type="submit" class="kwc-send" aria-label="Send">→</button></form>' +
      '<p class="kwc-note">I’m an AI trained on this website, so I can get things wrong. Chats are saved and shared with Kyle. <a href="privacy.html">Privacy</a> · <a href="contact.html">Contact Kyle</a></p>' +
    '</section>';
  document.body.appendChild(root);

  var btn = root.querySelector('.kwc-launch'), panel = root.querySelector('.kwc-panel'), log = root.querySelector('.kwc-log'),
      form = root.querySelector('.kwc-form'), input = root.querySelector('#kwc-in'), chips = root.querySelector('.kwc-chips');

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function fmt(t) {
    return esc(t)
      .replace(/(https?:\/\/[^\s<]+[^\s<.,)])/g, '<a href="$1" rel="noopener">$1</a>')
      .replace(/(^|[\s(])(\/(?:contact|for-sale|brand-identity|short-stay-consulting|business-automation|ventures|about|work-with-me|faq)\b)/g, '$1<a href="$2">kylewillmington.com.au$2</a>')
      .replace(/\n/g, '<br>');
  }
  function add(role, text) {
    var d = document.createElement('div'); d.className = 'kwc-msg ' + (role === 'user' ? 'me' : 'ai');
    d.innerHTML = fmt(text); log.appendChild(d); log.scrollTop = log.scrollHeight; return d;
  }
  function setChips(list) {
    chips.innerHTML = '';
    list.forEach(function (c) { var b = document.createElement('button'); b.type = 'button'; b.textContent = c; b.onclick = function () { send(c); }; chips.appendChild(b); });
  }

  var opened = false;
  function open() {
    panel.hidden = false; btn.setAttribute('aria-expanded', 'true'); root.classList.add('open');
    if (!opened) {
      opened = true;
      add('assistant', 'Hi, I’m an AI version of Kyle. Ask me about my story, TurnKey, NETALYST, how I can help your business, or what I have for sale.');
      if (!LIVE) add('assistant', '(Preview mode: these are sample answers. The real AI switches on when the site goes live.)');
      setChips(['What do you do?', 'How can you help my business?', 'Tell me about TurnKey', 'What’s for sale?']);
    }
    setTimeout(function () { input.focus(); }, 50);
  }
  function close() { panel.hidden = true; btn.setAttribute('aria-expanded', 'false'); root.classList.remove('open'); btn.focus(); }
  btn.onclick = function () { panel.hidden ? open() : close(); };
  root.querySelector('.kwc-close').onclick = close;
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !panel.hidden) close(); });
  input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit ? form.requestSubmit() : form.onsubmit(e); } });
  form.addEventListener('submit', function (e) { e.preventDefault(); send(input.value); });

  function send(text) {
    text = (text || '').trim(); if (!text || busy) return;
    busy = true; input.value = ''; chips.innerHTML = '';
    add('user', text); history.push({ role: 'user', content: text });
    var typing = add('assistant', '…'); typing.classList.add('typing');
    var done = function (reply) { typing.remove(); add('assistant', reply); history.push({ role: 'assistant', content: reply }); busy = false; };
    if (!LIVE) { setTimeout(function () { done(demo(text)); }, 650); return; }
    fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sid: sid, page: location.pathname, messages: history }) })
      .then(function (r) { return r.json(); })
      .then(function (r) { done(r.reply || 'Sorry, something went wrong. Please use /contact and I’ll get back to you.'); })
      .catch(function () { done('Sorry, I couldn’t connect just now. Please use /contact and I’ll get back to you.'); });
  }

  // Preview-only sample answers (the live site uses the real AI)
  function demo(t) {
    t = t.toLowerCase();
    if (/price|cost|quote|how much/.test(t)) return 'I quote every job personally after a quick chat, so I can’t give prices here. I can take your details now and get back to you, or you can use /contact.';
    if (/sale|buy|louis|bag/.test(t)) return 'At the moment I have a rare Louis Vuitton bag for sale, price on enquiry. You can see it and enquire at /for-sale, or leave your details here and I’ll be in touch.';
    if (/turnkey|stay|airbnb|bnb/.test(t)) return 'TurnKey Group is building Australia’s complete short-stay solution: TurnKey Stays for Gold Coast stays, TurnKey BnBs for setup and consulting, TurnKey Access for key safes in Main Beach, TurnKey Pro for host products and TurnKey Services for guests. Have a look at /ventures.';
    if (/help|business|work with|hire/.test(t)) return 'I help in three ways: brand identity and online presence, short-stay setup and consulting, and business systems and automation. Would you like to leave your details so I can get back to you personally, or use /contact?';
    if (/netalyst|brand|logo|website/.test(t)) return 'NETALYST is my brand consultancy: logos, brand guides, websites and Google presence, so your business looks as good online as it is in person. More at /brand-identity.';
    if (/atlas|nova|ai/.test(t)) return 'ATLAS is the AI operations agent I’m building for short-stay businesses, and NOVA is my personal AI assistant. Both are in development. More at /ventures.';
    return 'I’m an entrepreneur on the Gold Coast with 20+ years in business. I run TurnKey Group and NETALYST, and I’m building the ATLAS and NOVA AI agents. What would you like to know?';
  }
})();
