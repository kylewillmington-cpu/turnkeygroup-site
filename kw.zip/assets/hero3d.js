// KW 3D hero: gold monogram + drifting gold dust. Loaded after page load.
import * as THREE from './vendor/three.module.min.js';
import { RoomEnvironment } from './vendor/RoomEnvironment.js';

const host = document.querySelector('.hero');
const canvas = document.getElementById('hero3d');
if (host && canvas) start();

function start() {
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  } catch (e) { return; }
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const small = innerWidth < 760;
  renderer.setPixelRatio(Math.min(devicePixelRatio, small ? 1.25 : 1.75));
  let software = false;
  try { const gl = renderer.getContext(), ext = gl.getExtension('WEBGL_debug_renderer_info');
    const r = ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : ''; software = /swiftshader|llvmpipe|software/i.test(r); } catch (e) {}
  const still = reduce || software || (navigator.connection && navigator.connection.saveData);
  const minFrame = small ? 1000 / 30 : 0;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 200);
  camera.position.set(0, 0, 26);

  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(renderer), 0.04).texture;
  const key = new THREE.DirectionalLight(0xffe2b0, 2.2); key.position.set(6, 8, 10); scene.add(key);
  const rim = new THREE.DirectionalLight(0x8fa8ff, 0.6); rim.position.set(-10, -4, -6); scene.add(rim);

  // Materials
  const gold = new THREE.MeshStandardMaterial({ color: 0xC9A86A, metalness: 1, roughness: 0.26 });
  const goldSoft = new THREE.MeshStandardMaterial({ color: 0xB89660, metalness: 1, roughness: 0.42 });

  // Build the mark from its SVG strokes (120x120 box, y down)
  const P = (x, y) => new THREE.Vector3((x - 60) / 10, -(y - 60) / 10, 0);
  function bar(a, b, thick, depth, mat, extend = true) {
    const A = P(...a), B = P(...b);
    const len = A.distanceTo(B) + (extend ? thick : 0);
    const g = new THREE.BoxGeometry(len, thick, depth);
    const m = new THREE.Mesh(g, mat);
    m.position.copy(A).add(B).multiplyScalar(0.5);
    m.rotation.z = Math.atan2(B.y - A.y, B.x - A.x);
    return m;
  }
  const mark = new THREE.Group();
  const T = 0.66, D = 0.9;
  [[[26, 28], [26, 96]], [[26, 64], [56, 28]], [[26, 64], [44, 96]], [[44, 96], [60, 56]], [[60, 56], [76, 96]], [[76, 96], [112, 8]]]
    .forEach(([a, b]) => mark.add(bar(a, b, T, D, gold)));
  // Open frame
  const FT = 0.26, FD = 0.5;
  [[[84, 4], [4, 4]], [[4, 4], [4, 116]], [[4, 116], [116, 116]], [[116, 116], [116, 36]]]
    .forEach(([a, b]) => { const m = bar(a, b, FT, FD, goldSoft); m.position.z = -0.6; mark.add(m); });
  scene.add(mark);

  // Gold dust
  const N = small ? 380 : 1100;
  const pos = new Float32Array(N * 3), spd = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    pos[i * 3] = (Math.random() - 0.5) * 60;
    pos[i * 3 + 1] = (Math.random() - 0.5) * 36;
    pos[i * 3 + 2] = (Math.random() - 0.5) * 30 - 4;
    spd[i] = 0.004 + Math.random() * 0.012;
  }
  const dustGeo = new THREE.BufferGeometry();
  dustGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const sprite = (() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const x = c.getContext('2d'), gr = x.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(255,236,196,1)'); gr.addColorStop(0.35, 'rgba(226,203,156,.55)'); gr.addColorStop(1, 'rgba(201,168,106,0)');
    x.fillStyle = gr; x.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  })();
  const dust = new THREE.Points(dustGeo, new THREE.PointsMaterial({ size: 0.16, map: sprite, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.85 }));
  scene.add(dust);

  // Layout: centre the mark on the photo so the gold frame surrounds it
  let base = new THREE.Vector3();
  function resize() {
    const w = host.clientWidth, h = host.clientHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h; camera.updateProjectionMatrix();
    const halfH = camera.position.z * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)), halfW = halfH * camera.aspect;
    const photo = host.querySelector('.hero-stage');
    const hr = host.getBoundingClientRect(), r = photo ? photo.getBoundingClientRect() : null;
    if (r && r.width) {
      const cx = (r.left - hr.left + r.width / 2) / w, cy = (r.top - hr.top + r.height / 2) / h;
      const pw = r.width / w * halfW * 2;
      mark.scale.setScalar((pw * 0.92) / 11.2);
      base.set((cx - 0.5) * 2 * halfW, -(cy - 0.5) * 2 * halfH, 0);
    } else { mark.scale.setScalar(0.8); base.set(halfW * 0.5, 0, -1.5); }
    mark.position.copy(base);
  }
  resize(); addEventListener('resize', resize);

  // Pointer parallax
  let tx = 0, ty = 0, mx = 0, my = 0;
  addEventListener('pointermove', e => { tx = (e.clientX / innerWidth - 0.5); ty = (e.clientY / innerHeight - 0.5); }, { passive: true });

  // Only render while hero is on screen
  let visible = true;
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; if (visible && !still) loop(); }).observe(host);

  const clock = new THREE.Clock();
  function frame() {
    const t = clock.getElapsedTime();
    mx += (tx - mx) * 0.04; my += (ty - my) * 0.04;
    mark.rotation.y = Math.sin(t * 0.32) * 0.45 + mx * 0.5;
    mark.rotation.x = Math.sin(t * 0.21) * 0.08 + my * 0.2;
    mark.position.y = base.y + Math.sin(t * 0.8) * 0.12;
    const p = dustGeo.attributes.position.array;
    for (let i = 0; i < N; i++) {
      p[i * 3 + 1] += spd[i];
      p[i * 3] += Math.sin(t * 0.3 + i) * 0.002;
      if (p[i * 3 + 1] > 18) p[i * 3 + 1] = -18;
    }
    dustGeo.attributes.position.needsUpdate = true;
    dust.rotation.y = mx * 0.15;
    camera.position.x = mx * 0.6; camera.position.y = -my * 0.4; camera.lookAt(camera.position.x * 0.5, camera.position.y * 0.5, 0);
    // fade out as you scroll past the hero
    canvas.style.opacity = Math.max(0, 1 - scrollY / (host.clientHeight * 0.9)).toFixed(3);
    renderer.render(scene, camera);
  }
  let running = false;
  function loop() {
    if (running) return; running = true;
    let last = 0;
    const tick = now => { if (!visible) { running = false; return; } if (!minFrame || now - last >= minFrame) { last = now; frame(); } requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  }
  if (still) { mark.rotation.y = -0.35; frame(); } else loop();
  host.classList.add('has-3d');
}
